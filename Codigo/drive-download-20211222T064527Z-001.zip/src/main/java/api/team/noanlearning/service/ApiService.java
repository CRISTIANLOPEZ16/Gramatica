package api.team.noanlearning.service;

import api.team.noanlearning.model.Gramatica;
import api.team.noanlearning.util.Response;

public interface ApiService {
		public Response ejecutarPasoAPaso(Response response);
		public Response obtenerCasoDePrueba();
}
