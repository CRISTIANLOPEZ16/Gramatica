package api.team.noanlearning.util;

public class Response {
		String paso;
		String codeResponse;
		String sigma;
		String variablesNoTerminales;
		String variablesTerminales;
		String variableInicial;
		
		public  interface Pasos{
			public static final String PASO_A_PASO_CHOMSKY="stepFullComsky";
			public static final String PASO_A_PASO_GREIBACH="stepFullGreibach";
			public static final String PASO_VARIABLES_INUTILES="uselessVar";
			public static final String PASO_VARIABLES_INALCANZABLES="unreachableVar";
			public static final String PASO_VARIABLES_NULL="nullVar";
			public static final String PASO_VARIABLES_UNITARIAS="unitaryVar";
			public static final String PASO_COMSKY="resolveChomsky";
			public static final String PASO_RECURSIVIDAD="deleteRecursivity";
			public static final String PASO_RECURSIVIDAD_INMEDIATA_IZQUIERDA="deleteLeftRecursivity";
			public static final String PASO_GREIBACH="resolveGreibach";
			public static final String VERIFICACION="verify";
			
			public static final String CODE_SATISFACTORIO="500";
			public static final String CODE_ERROR_INTEGRIDAD="error-integrity";
			public static final String CODE_ERROR_LOGICA="error-logic";
			public static final String CODE_ERROR_RESPUESTA_COMPARATIVA="incorrec-answer";
			public static final String CODE_ERROR_NO_OPERACION="operation404";
			 
				
		}
		
		

		public Response() {
			super();
		}

		public String getSigma() {
			return sigma;
		}

		public void setSigma(String sigma) {
			this.sigma = sigma;
		}

		public String getVariablesNoTerminales() {
			return variablesNoTerminales;
		}

		public void setVariablesNoTerminales(String variablesNoTerminales) {
			this.variablesNoTerminales = variablesNoTerminales;
		}

		public String getVariablesTerminales() {
			return variablesTerminales;
		}

		public void setVariablesTerminales(String variablesTerminales) {
			this.variablesTerminales = variablesTerminales;
		}

		public String getVariableInicial() {
			return variableInicial;
		}

		public void setVariableInicial(String variableInicial) {
			this.variableInicial = variableInicial;
		}

		public String getPaso() {
			return paso;
		}

		public void setPaso(String paso) {
			this.paso = paso;
		}

		public String getCodeResponse() {
			return codeResponse;
		}

		public void setCodeResponse(String codeResponse) {
			this.codeResponse = codeResponse;
		}
		
		
		public boolean validarIntegridadParaOperacion() {
			return paso!=null&&paso!=""&&sigma!=null&&sigma!=""&&variablesTerminales!=null&&variablesTerminales!=""
					&&variablesNoTerminales!=null&&variablesNoTerminales!=""&&variableInicial!=null&&variableInicial!="";
			
			
		}
		
}
