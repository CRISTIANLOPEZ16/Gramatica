package api.team.noanlearning.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jgrapht.graph.DefaultDirectedGraph;
import org.jgrapht.graph.DefaultEdge;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import api.team.noanlearning.contoller.Normalizacion;
import api.team.noanlearning.model.Gramatica;
import api.team.noanlearning.model.Palabra;
import api.team.noanlearning.service.ApiService;
import api.team.noanlearning.util.Response;
import exceptions.codigoResponseNoIdentificadoException;
@RestController  
public class ApiServiceImpl implements ApiService {
	
	@Autowired
	Normalizacion controller;
	
	@Override
	@CrossOrigin
	@RequestMapping(value="/step",method=RequestMethod.GET)
	public Response ejecutarPasoAPaso(Response peticion) {
		
		if(!peticion.validarIntegridadParaOperacion()) {
			peticion.setCodeResponse(Response.Pasos.CODE_ERROR_INTEGRIDAD);
			return peticion;
		}
		Gramatica g = controller.crearGramatica(peticion.getVariablesNoTerminales(), peticion.getVariablesTerminales(), peticion.getVariableInicial(),peticion.getSigma());
		Response response= new Response();
		String paso=peticion.getPaso();
		String estado="";
		try {
			g=ejecutarPaso(paso,g);
			estado=Response.Pasos.CODE_SATISFACTORIO;
			
		}catch(Exception e) {
			response.setCodeResponse(e.getMessage());
		}
		response.setCodeResponse(estado);
		response=construirRespuesta(response,g);
		return response;
	}

	private Gramatica ejecutarPaso(String paso,Gramatica g) throws Exception {
		switch(paso) {
		case Response.Pasos.PASO_A_PASO_CHOMSKY:
			g=controller.eliminarInutiles(g);
			g=controller.eliminarInalacanzables(g, g.getInicial());
			g=controller.eliminarNulas(g);
			g=controller.eliminarUnitarias(g);
			g=controller.aplicarChomsky(g);
			break;
		case Response.Pasos.PASO_A_PASO_GREIBACH:
			g=controller.aplicarChomsky(g);
			g=controller.eliminarRecursividadIzquierda(g);
			g=controller.eliminarRecursividadInmediataIzquierda(g);
			break;
		case Response.Pasos.PASO_VARIABLES_INALCANZABLES:
			g=controller.eliminarInalacanzables(g, g.getInicial());
			break;
		case Response.Pasos.PASO_VARIABLES_INUTILES:
			
			g=controller.eliminarInutiles(g);
			break;
		case Response.Pasos.PASO_VARIABLES_NULL:
			g=controller.eliminarNulas(g);
			break;
		case Response.Pasos.PASO_VARIABLES_UNITARIAS:
			g=controller.eliminarUnitarias(g);
			break;
		case Response.Pasos.PASO_COMSKY:
			g=controller.aplicarChomsky(g);
			break;
		case Response.Pasos.PASO_RECURSIVIDAD:
			g=controller.eliminarRecursividadIzquierda(g);
			break;
		case Response.Pasos.PASO_RECURSIVIDAD_INMEDIATA_IZQUIERDA:
			g=controller.eliminarRecursividadIzquierda(g);
			break;
		case Response.Pasos.PASO_GREIBACH:
			throw new codigoResponseNoIdentificadoException();
		default:
			throw new codigoResponseNoIdentificadoException();
		}
		return g;
	}

	private Response construirRespuesta(Response response,Gramatica g) {
		response.setSigma(g.getSigma().toString());
		response.setVariableInicial(g.getInicial());
		response.setVariablesNoTerminales(g.getNoTerminales().toString());
		response.setVariablesTerminales(g.getTerminales().toString());
		return response;
	}

	public Gramatica traducirPedicionAGramatica(Response r) {
		String []temp=r.getVariablesNoTerminales().split(",");
		List<String> varNoTerminales = new ArrayList<String>();  
		for(int i=0;i<temp.length;i++) {
		varNoTerminales.add(temp[i]);
		}
		temp=r.getVariablesTerminales().split(",");
		List<String> varTerminales = new ArrayList<String>();  
		for(int i=0;i<temp.length;i++) {
		varTerminales.add(temp[i]);
		}
		 Map<String, Set<Palabra>> sigma = new HashMap<>();
	     Gramatica g = new Gramatica(varTerminales, varNoTerminales, r.getVariableInicial(), sigma);
	     convertirStringASigma(r.getSigma(),g);
		return g;
	}
	
	public void convertirStringASigma( String sigmaA,Gramatica g) {
		 DefaultDirectedGraph<String, DefaultEdge> graph = new DefaultDirectedGraph<>(DefaultEdge.class);
	        String[] definiciones = sigmaA.split(",");
	        Map<String, Set<Palabra>> sigma = g.getSigma();
	        for(String def : definiciones){
	            String noTerminalDef = def.substring(0, 1);
	            if(!graph.containsVertex(noTerminalDef)){
	                graph.addVertex(noTerminalDef);
	            }
	            String[] array = def.substring(3).split("/");
	            Set<Palabra> palabras = new HashSet<>();
	            for (String palabra : array) {
	                Palabra p = new Palabra(palabra);
	                String[] simbolos = palabra.split("");
	                for (String simbolo : simbolos) {
	                    if(!graph.containsEdge(noTerminalDef, simbolo)){
	                        if(!graph.containsVertex(simbolo)){
	                            graph.addVertex(simbolo);
	                        }
	                        graph.addEdge(noTerminalDef, simbolo); 
	                    }
	                }
	                palabras.add(p);
	            }
	            sigma.put(noTerminalDef, palabras);
	        }
	        g.setSigma(sigma);
	        g.setGraph(graph);
	}
	
	@Override
	@CrossOrigin
	@RequestMapping(value="/example",method=RequestMethod.GET)
	public Response obtenerCasoDePrueba() {
		 String inicial = "A";
	        String noTerminales = "A,B,C,D,E,F,G,H";
	        String terminales = "0,1,2";
	        String sigma =
	                        "A->B1CD/GF/BDG/1,"+
	                        "B->CDE/DCE/F1/0/Î»,"+
	                        "C->DE/E/F/DE0E1/2,"+
	                        "D->B/CDE/DD1/0,"+
	                        "E->B1B2B/DE2/1,"+
	                        "F->DBEE2/F1/2,"+
	                        "H->BCD1/2";
	    Response response=new Response();
	    response.setVariableInicial(inicial);
	    response.setVariablesNoTerminales(noTerminales);
	    response.setVariablesTerminales(terminales);
	    response.setSigma(sigma);
	    response.setPaso(" a ");
	    response.setCodeResponse("example");
		return response;
	}
	
}
