package exceptions;

public class codigoResponseNoIdentificadoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

}
